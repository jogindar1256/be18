"use strict";
$(function() {
    setTimeout(function() {
        $(".hide-notification-popup").fadeOut(1000);
    }, 3000)
})