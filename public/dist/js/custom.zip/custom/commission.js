'use strict';

if ($('.main-body .page-wrapper').find('#commission-container').length) {
    $('.select2').select2()
}
