"use strict";
window.onload = function() {
                window.print();
            }