"use strict";
$(function(){
    $(document).on('submit', 'form', function(e) {
        $('.card').hide();
        $('.card-panel').show();
    });
})
